﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnaFarmerMarket.Data
{
    public interface IOrder
    {
        //task later
        void SqlOrderInformation(int customerID, string firstName, string lastName, string address, string city, string state, int zipcode);
    }


        





            
}
